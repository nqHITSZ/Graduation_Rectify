
lvalid不连续情况为测试

必须假设master axi stream接口的ready信号一直为高，即pready一直为高